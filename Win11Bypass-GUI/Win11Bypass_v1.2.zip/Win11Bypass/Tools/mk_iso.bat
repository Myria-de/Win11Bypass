@echo off
setlocal
SET ISOPATH=%~1
SET SOURCEDIR=%~2

if /i "%~1"=="" goto usage
if /i "%~2"=="" goto usage

:mkiso
echo Erstelle ISO

mkisofs.exe -iso-level 4 -udf -r -force-uppercase -duplicates-once -volid "WinSetup" -hide boot.catalog -hide-udf boot.catalog -b "boot/etfsboot.com" -no-emul-boot -boot-load-size 8 -eltorito-platform efi -b "efi/microsoft/boot/efisys.bin" -no-emul-boot -o %ISOPATH% %SOURCEDIR%

goto end

:usage
echo Erstellt bootfaehige Windows-8/10/11-ISO-Datei
echo.
echo mk_iso.bat ISO-Datei (Pfad\Dateiname.iso) Quell-Pfad
echo.

:end
echo Fertig
endlocal

