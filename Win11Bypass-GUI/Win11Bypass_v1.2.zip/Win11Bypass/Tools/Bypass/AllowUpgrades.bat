reg import AllowUpgrades.reg
pause